
% Use the function knnClassify to test performance on different datasets.



