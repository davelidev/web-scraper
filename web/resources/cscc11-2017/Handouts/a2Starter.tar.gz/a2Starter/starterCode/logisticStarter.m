% Use learnLogReg() to test performance on various datasets.
